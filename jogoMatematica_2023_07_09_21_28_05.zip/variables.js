// skecth.js
jumper = [];
fase = "menu";

// functions.js
var jogar = false;
var inst = false;
var cores = 5;
var mudanca = 5;


var larguraDaTela = 1000;
var alturaDaTela = 800;

// operacoes.js
var tamanhoSoma = 32;
var tamanhoSubtracao = 32;
var tamanhoMultiplicacao = 32;
var tamanhoDivisao = 32;

var opcaoA = 0;
var opcaoB = 0;
var opcaoC = 0;
var opcaoD = 0;
var numeroCerto = 0;
var numero1 = 0;
var numero2 = 0;
var gerarNovosDados = true;
var cor = 60;
var corA = 0;
var corB = 0;
var corC = 0;
var corD = 0;
var acertos = 0;
var tentativas = 0;
var tempo = 0;
var cronometro = 0;
var contarTempo = false;
var faseAtual = 0;
//var venceuOJogo = false;

//creditos.js
//tamanhoIconeVoltar = 67;
//imagens
//imagemVoltar = 0;
//function preload() {
  
//}