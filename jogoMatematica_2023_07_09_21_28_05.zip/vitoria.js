function vitoria()
{
  tamanhoVoltar = verificaSeRetorna();
  text("Parabéns por vencer o jogo! Você mostrou um domínio excepcional das operações básicas e está pronto para embarcar em uma jornada incrível através da matemática. Sinta-se à vontade para continuar jogando e aprendendo. Até logo!", larguraDaTela/2, alturaDaTela/4 - 20);
  image(imagemVoltar, 50, 700, tamanhoVoltar, tamanhoVoltar);
}